package org.example;
import java.util.Scanner;
import java.util.ArrayList;

public class Entrenador {
    private int id;
    private String nombre;
    private ArrayList<Pokemon> pokemon;
    private Pokedex pokedex;

    public Entrenador(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.pokemon = new ArrayList<>();
        this.pokedex = new Pokedex(id);
    }

    // Captura un Pokémon y lo registra en la Pokédex del entrenador.
    public void capturarPokemon(Pokemon p) {
        pokemon.add(p);
        pokedex.registrarPokemon(p);
        System.out.println(nombre + " ha capturado a " + p.getNombre()+". Yayy!");
    }

    // Libera un Pokémon según su índice en la lista.
    public void liberarPokemon(int indice) {
        if (indice >= 0 && indice < pokemon.size()) {
            Pokemon liberado = pokemon.remove(indice);
            System.out.println(nombre + " ha liberado a " + liberado.getNombre()+". ¡Chaíto!");
        } else {
            System.out.println("Índice inválido.");
        }
    }

    // BONUS
    // Curar un pokémon
    public void curarPokemon(int indice){
        if (indice < 0 || indice >= pokemon.size()) {
            System.out.println("Índice inválido. No hay ningún Pokémon en esa posición.");
            return;
        }
        Pokemon seleccionado = pokemon.get(indice);
        seleccionado.setVida(seleccionado.getVidaMax());
        System.out.println("El Pokémon " + seleccionado.getNombre() + " ha sido curado a su vida máxima");



    }

    // Intercambia un Pokémon con otro entrenador.
    public void intercambiarPokemon(Entrenador otro, int miIndice, int indiceOtro) {
        if (miIndice >= 0 && miIndice < pokemon.size() &&
                indiceOtro >= 0 && indiceOtro < otro.pokemon.size()) {
            Pokemon miPokemon = pokemon.get(miIndice);
            Pokemon pokemonOtro = otro.pokemon.get(indiceOtro);

            pokemon.set(miIndice, pokemonOtro);
            otro.pokemon.set(indiceOtro, miPokemon);

            System.out.println(nombre + " ha intercambiado a" + miPokemon.getNombre() +
                    " por el " + pokemonOtro.getNombre()  + " de " + otro.nombre);
            System.out.println("Se han registrado los datos de "+pokemonOtro+" en la pokédex");
            this.pokedex.registrarPokemon(pokemonOtro);
        } else {
            System.out.println("Alguno de los índices es inválido para el intercambio.");
        }
    }

    // Menú interactivo de la Pokedex.
    public void usarPokedex(Scanner sc) {
        while (true) {
            System.out.println("\n--- Menú Pokedex ---");
            System.out.println("1) Registrar Pokémon manualmente");
            System.out.println("2) Buscar Pokémon");
            System.out.println("3) Mostrar todos los Pokémon registrados");
            System.out.println("0) Salir de la Pokedex");
            System.out.print("Seleccione una opción: ");
            int opcion = sc.nextInt();
            sc.nextLine();
            if (opcion == 1) {
                System.out.print("Ingrese el id del Pokémon: ");
                int idP = sc.nextInt();
                sc.nextLine();
                System.out.print("Ingrese el nombre: ");
                String nombrePoke = sc.nextLine();
                System.out.print("Ingrese el tipo (AGUA, FUEGO, PLANTA): ");
                String tipoStr = sc.nextLine().toUpperCase();
                TipoPoke tipo;
                try {
                    tipo = TipoPoke.valueOf(tipoStr);
                } catch (IllegalArgumentException e) {
                    System.out.println("Tipo inválido. Se asignará PLANTA por defecto.");
                    tipo = TipoPoke.PLANTA;
                }
                System.out.print("Ingrese el nivel: ");
                int nivel = sc.nextInt();
                sc.nextLine();
                System.out.print("Ingrese la vida: ");
                int vida = sc.nextInt();
                sc.nextLine();
                System.out.print("Ingrese el daño: ");
                int dmg = sc.nextInt();
                sc.nextLine();
                Pokemon nuevo = new Pokemon(idP, nombrePoke, tipo, nivel, vida, dmg);
                pokedex.registrarPokemon(nuevo);

            } else if (opcion == 2) {
                System.out.print("Ingrese el nombre del Pokémon a buscar: ");
                String nombreBuscar = sc.nextLine();
                pokedex.buscarPokemon(nombreBuscar);

            } else if (opcion == 3) {
                pokedex.mostrarRegistrados();

            } else if (opcion == 0) {
                break;
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }

    // Muestra los Pokémon que posee el entrenador.
    public void mostrarPokemon() {
        if (pokemon.isEmpty()){
            System.out.println(nombre + " no posee Pokémon aún.");
        } else {
            System.out.println("Pokémon de " + nombre + ":");
            for (int i = 0; i < pokemon.size(); i++) {
                System.out.println(i + ") " + pokemon.get(i).toString());
            }
        }
    }

    public ArrayList<Pokemon> getPokemon() {
        return pokemon;
    }

    public Pokedex getPokedex() {
        return pokedex;
    }

    public String getNombre(){
        return nombre;
    }
}
