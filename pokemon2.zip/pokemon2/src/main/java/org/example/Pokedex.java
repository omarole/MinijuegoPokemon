package org.example;
import java.util.*;

public class Pokedex {
    private int id;
    private ArrayList<Pokemon> registrados;

    public Pokedex(int id) {
        this.id = id;
        this.registrados = new ArrayList<>();
    }

    // Registra un Pokémon si aún no se encuentra en la lista.
    public void registrarPokemon(Pokemon p) {
        boolean existe = false;
        for (Pokemon reg : registrados) {
            if (reg.getId() == p.getId()) {
                existe = true;
                break;
            }
        }
        if (!existe) {
            registrados.add(p);
            System.out.println("Se ha registrado a " + p.getNombre() + " en la Pokedex.");
        }
    }

    // Busca un Pokémon por nombre
    public Pokemon buscarPokemon(String nombre) {
        for (Pokemon p : registrados) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Pokémon encontrado: " + p.toString());
                return p;
            }
        }
        System.out.println("No se encontró ningún Pokémon con el nombre " + nombre);
        return null;
    }

    // Muestra todos los Pokémon registrados en la Pokedex
    public void mostrarRegistrados() {
        if (registrados.isEmpty()) {
            System.out.println("La Pokedex no tiene registros aún.");
        } else {
            System.out.println("Pokémon en la Pokedex:");
            for (Pokemon p : registrados) {
                System.out.println(p.toString());
            }
        }
    }

    // Devuelve la lista de Pokémon registrados para guardar en archivo
    public List<Pokemon> getRegistrados() {
        return registrados;
    }
}
