package org.example;

import java.util.ArrayList;
import java.util.List;

public class Pokemon {
    private int id;
    private String nombre;
    private TipoPoke tipo;
    private int nivel;
    private int vida;
    private final int  vidaMax; // Apaño para los movimientos de curación
    private int dmg;

    public Pokemon(int id, String nombre, TipoPoke tipo, int nivel, int vida, int dmg) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivel = nivel;
        this.vida = vida;
        this.vidaMax = this.vida;
        this.dmg = dmg;
    }

    // Getters y Setters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public TipoPoke getTipo() { return tipo; }
    public int getNivel() { return nivel; }
    public int getVida() { return vida; }
    public int getDmg() { return dmg; }
    public void setVida(int vida) { this.vida = vida; }
    public int getVidaMax() {return vidaMax;}

    // AÑADIDO BONUS (nunca mejor dicho)
    // Metodo privado para calcular el bonus según efectividad.
    // Si se cumple alguna, se añade +20 de daño.
    private int obtenerBonusEfectividad(Pokemon enemigo, int dmgBase) {
        int bonus = 0;
        if (this.tipo == TipoPoke.PLANTA && enemigo.getTipo() == TipoPoke.AGUA) { // PLANTA vs AGUA
            bonus = 20;
        } else if (this.tipo == TipoPoke.AGUA && enemigo.getTipo() == TipoPoke.FUEGO) { // AGUA vs FUEGO
            bonus = 20;
        } else if (this.tipo == TipoPoke.FUEGO && enemigo.getTipo() == TipoPoke.PLANTA) { // FUEGO vs PLANTA
            bonus = 20;
        }
        return bonus;
    }

    // Ataque básico: quita 1 PV.
    // BONUS: Para darle más chicha, el movimiento será del mismo tipo que el pokemon.
    // Es decir, se añade bonus por efectividad.
    public void atacar(Pokemon enemigo) {
        int base = 1;
        int bonus = obtenerBonusEfectividad(enemigo, base);
        int totalDmg = base + bonus;
        enemigo.setVida(Math.max(enemigo.getVida() - totalDmg, 0));
        System.out.println(this.nombre + " ataca a " + enemigo.getNombre() + " y le quita " + totalDmg + " PV.");
    }

    // Ataques exclusivos para tipo AGUA
    public void pistolaAgua(Pokemon enemigo) {
        if (this.tipo == TipoPoke.AGUA) {
            int baseDmg = this.dmg + this.nivel * 5;
            int bonus = obtenerBonusEfectividad(enemigo, baseDmg);
            int totalDmg = baseDmg + bonus;
            enemigo.setVida(Math.max(enemigo.getVida() - totalDmg, 0));
            System.out.println(this.nombre + " usa Pistola Agua y le quita " + totalDmg + " PV a " + enemigo.getNombre());
        } else {
            System.out.println("El Pokémon " + this.nombre + " no es de tipo AGUA y no puede usar Pistola Agua.");
        }
    }

    public void hidropulso(Pokemon enemigo) {
        if (this.tipo == TipoPoke.AGUA) {
            int baseDmg = this.dmg * this.nivel + 2;
            int bonus = obtenerBonusEfectividad(enemigo, baseDmg);
            int totalDmg = baseDmg + bonus;
            enemigo.setVida(Math.max(enemigo.getVida() - totalDmg, 0));
            System.out.println(this.nombre + " usa Hidropulso y le quita " + totalDmg + " PV a " + enemigo.getNombre());
        } else {
            System.out.println("El Pokémon " + this.nombre + " no es de tipo AGUA y no puede usar Hidropulso.");
        }
    }

    // Ataque exclusivo para tipo FUEGO:
    // Se genera un número aleatorio: si es 0 no tiene efecto. Si es 1, quita toda la vida al rival.
    public void infierno(Pokemon enemigo) {
        if (this.tipo == TipoPoke.FUEGO) {

            int probabilidad = (int) (Math.random()*2); // 0 o 1
            if (probabilidad == 0) {
                System.out.println(this.nombre + " usa Infierno, pero no tiene efecto sobre " + enemigo.getNombre());
            } else {
                enemigo.setVida(0);
                System.out.println(this.nombre + " usa Infierno y deja a " + enemigo.getNombre() + " sin vida.");
            }
        } else {
            System.out.println("El Pokémon " + this.nombre + " no es de tipo FUEGO y no puede usar Infierno.");
        }
    }

    // AÑADIDO BONUS
    // Ataque exclusivo para tipo PLANTA:
    // Se genera un número aleatorio (de 0 a 3):
    // 1) si es 0, no tiene efecto;
    // 2) si 1 ó 2, hace 20 de daño y el usuario recupera 10 de vida
    // 3) si sale 3, crítico! Hace 40 de daño y recupera tanta vida como daño inflingido.
    public void absorber(Pokemon enemigo){
        int dmg = 0;
        int bonus = obtenerBonusEfectividad(enemigo, dmg);
        int total = 0;

        if (this.tipo == TipoPoke.PLANTA){
            int probabilidad = (int) (Math.random() * 4);
            if (probabilidad ==0 ){
                System.out.println( this.nombre+ " ha usado absorber... Y ha fallado :(");
            }

            else if (probabilidad == 1 || probabilidad == 2){
                dmg = 20;
                total = dmg + bonus;
                enemigo.setVida(enemigo.getVida()-total);

                if (this.getVida()+10>this.getVidaMax()){
                    this.setVida(this.getVidaMax());
                    System.out.println(this.nombre+ " ha usado absorber... ¡Y acierta! ¡Inflinge" + total+ " de daño y se recupera a tope!.");
                }
                else {
                    this.setVida(this.getVida() + 10);
                    System.out.println(this.nombre + " ha usado absorber... ¡Y acierta! ¡Inflinge" + total + " de daño y recupera 10 PS!");
                }
            }

            else {
                dmg = 40;
                total = dmg + bonus;

                enemigo.setVida(enemigo.getVida()-total);
                if (this.getVida()+total>this.getVidaMax()){
                    this.setVida(this.getVidaMax());
                    System.out.println(this.nombre+ " ha usado absorber... ¡¡CRÍTICO!! ¡Inflinge" + total+ " de daño y se recupera a tope!.");
                }
                else {
                    this.setVida(this.getVida() + total);
                    System.out.println(this.nombre + " ha usado absorber... ¡¡CRÍTICO!! ¡Inflinge " + total + " de daño y recupera" + total + " PS!");
                }
            }
        }
    }

    // Devuelve la lista de ataques disponibles según el tipo.
    public List<String> ataquesDisponibles() {
        List<String> ataques = new ArrayList<>();
        ataques.add("atacar básico");
        if (this.tipo == TipoPoke.AGUA) {
            ataques.add("pistolaAgua");
            ataques.add("hidropulso");
        }
        if (this.tipo == TipoPoke.FUEGO) {
            ataques.add("infierno");
        }
        if (this.tipo == TipoPoke.PLANTA){
            ataques.add("absorber");
        }
        return ataques;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Tipo: " + tipo +
                ", Nivel: " + nivel + ", Vida: " + vida + ", Daño: " + dmg;
    }
}


