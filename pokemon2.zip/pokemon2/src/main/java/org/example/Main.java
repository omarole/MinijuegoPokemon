package org.example;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {
    // Lista que contendrá los Pokémon iniciales cargados desde el JSON.
    private static ArrayList<Pokemon> pokemonIniciales = new ArrayList<>();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Entrenador entrenador = null;
        boolean salir = false;

        while (!salir) {
            System.out.println("\n=== MENÚ PRINCIPAL ===");
            System.out.println("1) Crear Entrenador");
            System.out.println("2) Cargar Pokémon iniciales desde .json");
            System.out.println("3) Capturar un Pokémon");
            System.out.println("4) Liberar un Pokémon");
            System.out.println("5) Intercambiar un Pokémon con otro entrenador");
            System.out.println("6) Utilizar la Pokédex");
            System.out.println("7) Mostrar Pokémon del Entrenador");
            System.out.println("8) Combate");
            System.out.println("9) Curar pokémon");
            System.out.println("10) Guardar Pokédex en .txt");
            System.out.println("0) Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = sc.nextInt();
            sc.nextLine();

            switch(opcion) {
                case 1: //Crear Entrenador
                    System.out.print("Ingrese el id del entrenador: ");
                    int idEntrenador = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Ingrese el nombre del entrenador: ");
                    String nombreEntrenador = sc.nextLine();
                    entrenador = new Entrenador(idEntrenador, nombreEntrenador);
                    System.out.println("Entrenador " + nombreEntrenador + " creado.");
                    break;

                case 2: //Cargar Pokémon iniciales desde .json

                    try {
                        String contenido = new String(Files.readAllBytes(Paths.get("src/main/java/org/example/pokemon.json")));
                        Gson gson = new Gson();
                        // Definimos el tipo para que Gson sepa que es una lista de Pokémon.
                        Type listType = new TypeToken<List<Pokemon>>() {}.getType();
                        List<Pokemon> lista = gson.fromJson(contenido, listType);
                        pokemonIniciales = new ArrayList<>(lista);
                        System.out.println("Se han cargado " + pokemonIniciales.size() + " Pokémon desde el archivo JSON.");
                    } catch (IOException e) {
                        System.out.println("Error al cargar el archivo pokemon.json");
                        e.printStackTrace();
                    }
                    break;

                case 3: //Capturar un Pokémon
                    if (entrenador == null) {
                        System.out.println("Primero crea un entrenador (opción 1).");
                    } else {
                        if (pokemonIniciales.isEmpty()) {
                            System.out.println("No hay Pokémon disponibles. Cargue los Pokémon iniciales primero (usar la opción 2).");
                        } else {
                            System.out.println("Pokémon disponibles para capturar:");
                            for (int i = 0; i < pokemonIniciales.size(); i++) {
                                System.out.println(i + ") " + pokemonIniciales.get(i).toString());
                            }
                            System.out.print("Seleccione el índice del Pokémon a capturar: ");
                            int index = sc.nextInt();
                            sc.nextLine();
                            if (index >= 0 && index < pokemonIniciales.size()) {
                                entrenador.capturarPokemon(pokemonIniciales.get(index));
                            } else {
                                System.out.println("Índice inválido.");
                            }
                        }
                    }
                    break;

                case 4: //Liberar un Pokémon
                    if (entrenador == null) {
                        System.out.println("Primero crea un entrenador (opción 1).");
                    } else {
                        entrenador.mostrarPokemon();
                        System.out.print("Ingrese el índice del Pokémon a liberar: ");
                        int ind = sc.nextInt();
                        sc.nextLine();
                        entrenador.liberarPokemon(ind);
                    }
                    break;

                case 5: //Intercambiar Pokémon
                    // Se crea un segundo entrenador para el intercambio.
                    System.out.println("Creando un segundo entrenador para el intercambio.");
                    Entrenador otroEntrenador = new Entrenador(999, "Rival");
                    if (!pokemonIniciales.isEmpty()) {
                        Random random = new Random();
                        int indexRandom = random.nextInt(pokemonIniciales.size());
                        otroEntrenador.capturarPokemon(pokemonIniciales.get(indexRandom));
                    }
                    if (entrenador == null) {
                        System.out.println("Primero crea un entrenador (opción 1).");
                    } else {
                        System.out.println("Tus Pokémon:");
                        entrenador.mostrarPokemon();
                        System.out.print("Seleccione el índice de tu Pokémon a intercambiar: ");
                        int miInd = sc.nextInt();
                        sc.nextLine();
                        System.out.println("Pokémon de " + otroEntrenador.getNombre() + ":");
                        otroEntrenador.mostrarPokemon();
                        System.out.print("Seleccione el índice del Pokémon del otro entrenador: ");
                        int otroInd = sc.nextInt();
                        sc.nextLine();
                        entrenador.intercambiarPokemon(otroEntrenador, miInd, otroInd);
                    }
                    break;

                case 6: //Utilizar la Pokédex
                    if (entrenador == null) {
                        System.out.println("Primero crea un entrenador (opción 1).");
                    } else {
                        entrenador.usarPokedex(sc);
                    }
                    break;

                case 7: //Mostrar Pokémon del Entrenador
                    if (entrenador == null) {
                        System.out.println("Primero crea un entrenador (opción 1).");
                    } else {
                        entrenador.mostrarPokemon();
                    }
                    break;

                case 8: //Combate
                    if (entrenador == null) {
                        System.out.println("Primero crea un entrenador (opción 1).");
                    } else {
                        if (entrenador.getPokemon().isEmpty()){
                            System.out.println("No tienes Pokémon para combatir.");
                        } else if (pokemonIniciales.isEmpty()) {
                            System.out.println("No hay Pokémon enemigos disponibles. Cargue los Pokémon iniciales primero (opción 2).");
                        } else {
                            System.out.println("Selecciona tu Pokémon para el combate:");
                            entrenador.mostrarPokemon();
                            System.out.print("Ingrese el índice de tu Pokémon: ");
                            int indiceCombate = sc.nextInt();
                            sc.nextLine();

                            if (indiceCombate < 0 || indiceCombate >= entrenador.getPokemon().size()) {
                                System.out.println("Índice inválido.");
                            } else {
                                // Escoger un Pokémon rival de forma aleatoria.
                                Random rand = new Random();
                                Pokemon enemigo = pokemonIniciales.get(rand.nextInt(pokemonIniciales.size()));
                                Batalla batalla = new Batalla(entrenador.getPokemon().get(indiceCombate), enemigo);
                                batalla.iniciar(sc);
                            }
                        }
                    }
                    break;

                case 9: // Curar pokémon
                    if(entrenador != null){
                        entrenador.mostrarPokemon();
                        System.out.print("Seleccione el índice del Pokémon a curar: ");
                        int indiceCurar = sc.nextInt();
                        sc.nextLine();
                        entrenador.curarPokemon(indiceCurar);
                    } else {
                        System.out.println("Primero debe crear un entrenador.");
                    }
                    break;

                case 10: //Guardar Pokédex en .txt
                    if (entrenador == null) {
                        System.out.println("Primero crea un entrenador (opción 1).");
                    } else {
                        guardarPokedexEnTxt(entrenador.getPokedex());
                    }
                    break;

                case 0:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
        sc.close();
        System.out.println("Programa finalizado. Adiosito!");
    }

    // Guarda el contenido de la Pokédex en un archivo TXT.
    private static void guardarPokedexEnTxt(Pokedex pokedex) {
        String nombreArchivo = "pokedex.txt";
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo))) {
            for (Pokemon p : pokedex.getRegistrados()) {
                bw.write(p.toString());
                bw.newLine();
            }
            System.out.println("La Pokedex ha sido guardada en " + nombreArchivo);
        } catch(IOException e) {
            System.out.println("Error al escribir en " + nombreArchivo);
        }
    }
}