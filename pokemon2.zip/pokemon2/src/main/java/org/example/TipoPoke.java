package org.example;

public enum TipoPoke {
    AGUA, FUEGO, PLANTA;
}
