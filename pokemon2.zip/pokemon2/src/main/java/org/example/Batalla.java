package org.example;
import java.util.*;

public class Batalla {
    private Pokemon pokemonEntrenador;
    private Pokemon pokemonEnemigo;

    public Batalla(Pokemon pokemonEntrenador, Pokemon pokemonEnemigo) {
        this.pokemonEntrenador = pokemonEntrenador;
        this.pokemonEnemigo = pokemonEnemigo;
    }


    public void iniciar(Scanner sc) {
        System.out.println("--- Comienza la Batalla ---");
        System.out.println("Tu Pokémon: " + pokemonEntrenador.toString());
        System.out.println("Pokémon rival: " + pokemonEnemigo.toString());

        while (pokemonEntrenador.getVida() > 0 && pokemonEnemigo.getVida() > 0) {
            System.out.println("\nTurno del entrenador. Vida de " + pokemonEntrenador.getNombre() + ": " + pokemonEntrenador.getVida());
            System.out.println("Vida del rival (" + pokemonEnemigo.getNombre() + "): " + pokemonEnemigo.getVida());
            List<String> ataques = pokemonEntrenador.ataquesDisponibles();
            System.out.println("Selecciona el ataque:");
            for (int i = 0; i < ataques.size(); i++) {
                System.out.println(i + ") " + ataques.get(i));
            }
            int op = sc.nextInt();
            sc.nextLine();
            // Ejecuta el ataque seleccionado.
            switch (ataques.get(op)) {
                case "atacar básico":
                    pokemonEntrenador.atacar(pokemonEnemigo);
                    break;
                case "pistolaAgua":
                    pokemonEntrenador.pistolaAgua(pokemonEnemigo);
                    break;
                case "hidropulso":
                    pokemonEntrenador.hidropulso(pokemonEnemigo);
                    break;
                case "infierno":
                    pokemonEntrenador.infierno(pokemonEnemigo);
                    break;
                case "absorber":
                    pokemonEntrenador.absorber(pokemonEnemigo);
                    break;
                default:
                    System.out.println("Ataque no reconocido.");
                    break;
            }

            // Verifica si el Pokémon rival ha sido derrotado.
            if (pokemonEnemigo.getVida() <= 0) {
                System.out.println("¡El Pokémon rival ha sido derrotado!");
                break;
            }

            // Ataque del Pokémon enemigo elegido aleatoriamente.
            System.out.println("\nTurno del rival:");
            List<String> ataquesEnemigo = pokemonEnemigo.ataquesDisponibles();
            Random random = new Random();
            int atqRival = random.nextInt(ataquesEnemigo.size());
            String ataqueSeleccionado = ataquesEnemigo.get(atqRival);
            System.out.println("El rival elige " + ataqueSeleccionado);
            switch (ataqueSeleccionado) {
                case "atacar básico":
                    pokemonEnemigo.atacar(pokemonEntrenador);
                    break;
                case "pistolaAgua":
                    pokemonEnemigo.pistolaAgua(pokemonEntrenador);
                    break;
                case "hidropulso":
                    pokemonEnemigo.hidropulso(pokemonEntrenador);
                    break;
                case "infierno":
                    pokemonEnemigo.infierno(pokemonEntrenador);
                    break;
                case "absorber":
                    pokemonEnemigo.absorber(pokemonEntrenador);
                    break;
            }
            // Verifica si tu Pokémon ha sido derrotado.
            if (pokemonEntrenador.getVida() <= 0) {
                System.out.println("¡Tu Pokémon ha sido derrotado!");
                break;
            }
        }

        System.out.println("--- Fin de la Batalla ---\n");
        if (pokemonEntrenador.getVida()<=0) {
            System.out.println("Perdites :((");
        }
        if (pokemonEnemigo.getVida()<=0){
            System.out.println("Ganates! :D");
        }
        System.out.println("recuerda curar a tus pokémon antes del próximo combate (opción 9)");
    }
}
